clc;
clear;
close all;
g=9.8;
M=6.157;
m=1;
l=0.56;