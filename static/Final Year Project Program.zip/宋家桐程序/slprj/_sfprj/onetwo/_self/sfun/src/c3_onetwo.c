/* Include files */

#include <stddef.h>
#include "blas.h"
#include "onetwo_sfun.h"
#include "c3_onetwo.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "onetwo_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(sfGlobalDebugInstanceStruct,S);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c3_debug_family_names[38] = { "j", "bt", "t1", "T1", "T3",
  "T5", "T2", "T6", "t2", "t3", "v1", "s1", "v2", "s2", "v3", "s3", "bt2", "t4",
  "t5", "t6", "t7", "T4", "v4", "s4", "v5", "s5", "v6", "s6", "bt22", "bt33",
  "nargin", "nargout", "u", "a", "v", "t", "J", "ss" };

/* Function Declarations */
static void initialize_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void initialize_params_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void enable_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void disable_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void c3_update_debugger_state_c3_onetwo(SFc3_onetwoInstanceStruct
  *chartInstance);
static const mxArray *get_sim_state_c3_onetwo(SFc3_onetwoInstanceStruct
  *chartInstance);
static void set_sim_state_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_st);
static void finalize_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void sf_gateway_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void mdl_start_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void c3_chartstep_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void initSimStructsc3_onetwo(SFc3_onetwoInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber, uint32_T c3_instanceNumber);
static const mxArray *c3_sf_marshallOut(void *chartInstanceVoid, void *c3_inData);
static real_T c3_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_ss, const char_T *c3_identifier);
static real_T c3_b_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData);
static void c3_info_helper(const mxArray **c3_info);
static const mxArray *c3_emlrt_marshallOut(const char * c3_b_u);
static const mxArray *c3_b_emlrt_marshallOut(const uint32_T c3_b_u);
static real_T c3_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T c3_b_a);
static void c3_eml_scalar_eg(SFc3_onetwoInstanceStruct *chartInstance);
static real_T c3_b_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a);
static real_T c3_c_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a);
static void c3_eml_error(SFc3_onetwoInstanceStruct *chartInstance);
static void c3_b_eml_error(SFc3_onetwoInstanceStruct *chartInstance);
static real_T c3_d_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a);
static const mxArray *c3_b_sf_marshallOut(void *chartInstanceVoid, void
  *c3_inData);
static int32_T c3_c_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData);
static uint8_T c3_d_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_is_active_c3_onetwo, const char_T *c3_identifier);
static uint8_T c3_e_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId);
static void init_dsm_address_info(SFc3_onetwoInstanceStruct *chartInstance);
static void init_simulink_io_address(SFc3_onetwoInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  chartInstance->c3_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c3_is_active_c3_onetwo = 0U;
}

static void initialize_params_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c3_update_debugger_state_c3_onetwo(SFc3_onetwoInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c3_onetwo(SFc3_onetwoInstanceStruct
  *chartInstance)
{
  const mxArray *c3_st;
  const mxArray *c3_y = NULL;
  real_T c3_hoistedGlobal;
  real_T c3_b_u;
  const mxArray *c3_b_y = NULL;
  uint8_T c3_b_hoistedGlobal;
  uint8_T c3_c_u;
  const mxArray *c3_c_y = NULL;
  c3_st = NULL;
  c3_st = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_createcellmatrix(2, 1), false);
  c3_hoistedGlobal = *chartInstance->c3_ss;
  c3_b_u = c3_hoistedGlobal;
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", &c3_b_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 0, c3_b_y);
  c3_b_hoistedGlobal = chartInstance->c3_is_active_c3_onetwo;
  c3_c_u = c3_b_hoistedGlobal;
  c3_c_y = NULL;
  sf_mex_assign(&c3_c_y, sf_mex_create("y", &c3_c_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 1, c3_c_y);
  sf_mex_assign(&c3_st, c3_y, false);
  return c3_st;
}

static void set_sim_state_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_st)
{
  const mxArray *c3_b_u;
  chartInstance->c3_doneDoubleBufferReInit = true;
  c3_b_u = sf_mex_dup(c3_st);
  *chartInstance->c3_ss = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_b_u, 0)), "ss");
  chartInstance->c3_is_active_c3_onetwo = c3_d_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_b_u, 1)), "is_active_c3_onetwo");
  sf_mex_destroy(&c3_b_u);
  c3_update_debugger_state_c3_onetwo(chartInstance);
  sf_mex_destroy(&c3_st);
}

static void finalize_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void sf_gateway_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_u, 0U);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_a, 1U);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_v, 2U);
  chartInstance->c3_sfEvent = CALL_EVENT;
  c3_chartstep_c3_onetwo(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_onetwoMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_ss, 3U);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_t, 4U);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c3_J, 5U);
}

static void mdl_start_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c3_chartstep_c3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  real_T c3_hoistedGlobal;
  real_T c3_b_hoistedGlobal;
  real_T c3_c_hoistedGlobal;
  real_T c3_d_hoistedGlobal;
  real_T c3_e_hoistedGlobal;
  real_T c3_b_u;
  real_T c3_b_a;
  real_T c3_b_v;
  real_T c3_b_t;
  real_T c3_b_J;
  uint32_T c3_debug_family_var_map[38];
  real_T c3_j;
  real_T c3_bt;
  real_T c3_t1;
  real_T c3_T1;
  real_T c3_T3;
  real_T c3_T5;
  real_T c3_T2;
  real_T c3_T6;
  real_T c3_t2;
  real_T c3_t3;
  real_T c3_v1;
  real_T c3_s1;
  real_T c3_v2;
  real_T c3_s2;
  real_T c3_v3;
  real_T c3_s3;
  real_T c3_bt2;
  real_T c3_t4;
  real_T c3_t5;
  real_T c3_t6;
  real_T c3_t7;
  real_T c3_T4;
  real_T c3_v4;
  real_T c3_s4;
  real_T c3_v5;
  real_T c3_s5;
  real_T c3_v6;
  real_T c3_s6;
  real_T c3_bt22;
  real_T c3_bt33;
  real_T c3_nargin = 5.0;
  real_T c3_nargout = 1.0;
  real_T c3_b_ss;
  real_T c3_A;
  real_T c3_B;
  real_T c3_x;
  real_T c3_y;
  real_T c3_b_x;
  real_T c3_b_y;
  real_T c3_c_x;
  real_T c3_c_y;
  real_T c3_b_A;
  real_T c3_b_B;
  real_T c3_d_x;
  real_T c3_d_y;
  real_T c3_e_x;
  real_T c3_e_y;
  real_T c3_f_x;
  real_T c3_f_y;
  real_T c3_c_A;
  real_T c3_c_B;
  real_T c3_g_x;
  real_T c3_g_y;
  real_T c3_h_x;
  real_T c3_h_y;
  real_T c3_i_x;
  real_T c3_i_y;
  real_T c3_j_y;
  real_T c3_d_A;
  real_T c3_d_B;
  real_T c3_j_x;
  real_T c3_k_y;
  real_T c3_k_x;
  real_T c3_l_y;
  real_T c3_l_x;
  real_T c3_m_y;
  real_T c3_d0;
  real_T c3_e_A;
  real_T c3_e_B;
  real_T c3_m_x;
  real_T c3_n_y;
  real_T c3_n_x;
  real_T c3_o_y;
  real_T c3_o_x;
  real_T c3_p_y;
  real_T c3_d1;
  real_T c3_f_A;
  real_T c3_f_B;
  real_T c3_p_x;
  real_T c3_q_y;
  real_T c3_q_x;
  real_T c3_r_y;
  real_T c3_r_x;
  real_T c3_s_y;
  real_T c3_t_y;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  boolean_T guard5 = false;
  boolean_T guard6 = false;
  boolean_T guard7 = false;
  boolean_T guard8 = false;
  boolean_T guard9 = false;
  boolean_T guard10 = false;
  boolean_T guard11 = false;
  boolean_T guard12 = false;
  boolean_T guard13 = false;
  boolean_T guard14 = false;
  boolean_T guard15 = false;
  boolean_T guard16 = false;
  boolean_T guard17 = false;
  boolean_T guard18 = false;
  boolean_T guard19 = false;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
  c3_hoistedGlobal = *chartInstance->c3_u;
  c3_b_hoistedGlobal = *chartInstance->c3_a;
  c3_c_hoistedGlobal = *chartInstance->c3_v;
  c3_d_hoistedGlobal = *chartInstance->c3_t;
  c3_e_hoistedGlobal = *chartInstance->c3_J;
  c3_b_u = c3_hoistedGlobal;
  c3_b_a = c3_b_hoistedGlobal;
  c3_b_v = c3_c_hoistedGlobal;
  c3_b_t = c3_d_hoistedGlobal;
  c3_b_J = c3_e_hoistedGlobal;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 38U, 38U, c3_debug_family_names,
    c3_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_j, 0U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_bt, 1U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t1, 2U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T1, 3U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T3, 4U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T5, 5U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T2, 6U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T6, 7U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t2, 8U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t3, 9U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v1, 10U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s1, 11U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v2, 12U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s2, 13U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v3, 14U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s3, 15U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_bt2, 16U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t4, 17U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t5, 18U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t6, 19U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_t7, 20U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_T4, 21U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v4, 22U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s4, 23U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v5, 24U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s5, 25U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_v6, 26U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_s6, 27U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_bt22, 28U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_bt33, 29U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_nargin, 30U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_nargout, 31U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_b_u, 32U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_b_a, 33U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_b_v, 34U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_b_t, 35U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML(&c3_b_J, 36U, c3_sf_marshallOut);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c3_b_ss, 37U, c3_sf_marshallOut,
    c3_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 3);
  c3_b_ss = 0.0;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 3);
  c3_A = c3_b_J * c3_b_a * c3_b_a;
  c3_B = c3_b_v;
  c3_x = c3_A;
  c3_y = c3_B;
  c3_b_x = c3_x;
  c3_b_y = c3_y;
  c3_c_x = c3_b_x;
  c3_c_y = c3_b_y;
  c3_j = c3_c_x / c3_c_y;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 4);
  c3_b_A = c3_b_v;
  c3_b_B = c3_b_J * c3_b_a;
  c3_d_x = c3_b_A;
  c3_d_y = c3_b_B;
  c3_e_x = c3_d_x;
  c3_e_y = c3_d_y;
  c3_f_x = c3_e_x;
  c3_f_y = c3_e_y;
  c3_bt = c3_f_x / c3_f_y;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 4);
  c3_t1 = c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 5);
  c3_T1 = c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 5);
  c3_T3 = c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 5);
  c3_T5 = c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 6);
  c3_c_A = c3_b_v;
  c3_c_B = c3_j * c3_bt;
  c3_g_x = c3_c_A;
  c3_g_y = c3_c_B;
  c3_h_x = c3_g_x;
  c3_h_y = c3_g_y;
  c3_i_x = c3_h_x;
  c3_i_y = c3_h_y;
  c3_j_y = c3_i_x / c3_i_y;
  c3_T2 = c3_j_y - c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 7);
  c3_T6 = c3_T2;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 8);
  c3_t2 = c3_T2 + c3_t1;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 9);
  c3_t3 = c3_t2 + c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 10);
  c3_v1 = 0.5 * c3_j * c3_T1 * c3_T1;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 10);
  c3_s1 = 0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_T1);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 11);
  c3_v2 = c3_v1 + c3_j * c3_T1 * c3_T2;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 11);
  c3_s2 = (c3_s1 + c3_v1 * c3_T2) + 0.5 * c3_j * c3_T1 * c3_b_mpower
    (chartInstance, c3_T2);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 12);
  c3_v3 = c3_v2 + 0.5 * c3_j * c3_b_mpower(chartInstance, c3_T1);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 12);
  c3_s3 = (c3_s2 + c3_v2 * c3_T3) + 0.33333333333333331 * c3_j * c3_mpower
    (chartInstance, c3_T3);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 14);
  c3_d_A = c3_b_u - 2.0 * c3_s3;
  c3_d_B = c3_b_v;
  c3_j_x = c3_d_A;
  c3_k_y = c3_d_B;
  c3_k_x = c3_j_x;
  c3_l_y = c3_k_y;
  c3_l_x = c3_k_x;
  c3_m_y = c3_l_y;
  c3_bt2 = c3_l_x / c3_m_y;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 15);
  c3_t4 = c3_t3 + c3_bt2;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 15);
  c3_t5 = c3_t4 + c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 15);
  c3_t6 = c3_t5 + c3_T2;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 15);
  c3_t7 = c3_t6 + c3_bt;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 16);
  c3_T4 = c3_bt2;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 18);
  c3_v4 = c3_v3;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 18);
  c3_s4 = c3_s3 + c3_v3 * c3_T4;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 19);
  c3_v5 = c3_v4 - 0.5 * c3_j * c3_b_mpower(chartInstance, c3_T5);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 19);
  c3_s5 = (c3_s4 + c3_v4 * c3_T5) - 0.16666666666666666 * c3_j * c3_mpower
    (chartInstance, c3_T5);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 20);
  c3_v6 = c3_v5 - c3_j * c3_T5 * c3_T6;
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 20);
  c3_s6 = (c3_s5 + c3_v5 * c3_T6) - 0.5 * c3_j * c3_T5 * c3_b_mpower
    (chartInstance, c3_T6);
  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 22);
  if (CV_EML_IF(0, 1, 0, CV_RELATIONAL_EVAL(4U, 0U, 0, c3_b_u, 2.0 * c3_s3, -1,
        5U, c3_b_u >= 2.0 * c3_s3))) {
    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 23);
    guard19 = false;
    if (CV_EML_COND(0, 1, 0, CV_RELATIONAL_EVAL(4U, 0U, 1, c3_b_t, 0.0, -1, 4U,
          c3_b_t > 0.0))) {
      if (CV_EML_COND(0, 1, 1, CV_RELATIONAL_EVAL(4U, 0U, 2, c3_b_t, c3_t1, -1,
            3U, c3_b_t <= c3_t1))) {
        CV_EML_MCDC(0, 1, 0, true);
        CV_EML_IF(0, 1, 1, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 25);
        c3_b_ss = 0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t);
      } else {
        guard19 = true;
      }
    } else {
      guard19 = true;
    }

    if (guard19 == true) {
      CV_EML_MCDC(0, 1, 0, false);
      CV_EML_IF(0, 1, 1, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 27);
    guard18 = false;
    if (CV_EML_COND(0, 1, 2, CV_RELATIONAL_EVAL(4U, 0U, 3, c3_b_t, c3_t1, -1, 4U,
          c3_b_t > c3_t1))) {
      if (CV_EML_COND(0, 1, 3, CV_RELATIONAL_EVAL(4U, 0U, 4, c3_b_t, c3_t2, -1,
            3U, c3_b_t <= c3_t2))) {
        CV_EML_MCDC(0, 1, 1, true);
        CV_EML_IF(0, 1, 2, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 29);
        c3_b_ss = (c3_s1 + c3_v1 * (c3_b_t - c3_t1)) + 0.5 * c3_j * c3_T1 *
          c3_b_mpower(chartInstance, c3_b_t - c3_t1);
      } else {
        guard18 = true;
      }
    } else {
      guard18 = true;
    }

    if (guard18 == true) {
      CV_EML_MCDC(0, 1, 1, false);
      CV_EML_IF(0, 1, 2, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 31);
    guard17 = false;
    if (CV_EML_COND(0, 1, 4, CV_RELATIONAL_EVAL(4U, 0U, 5, c3_b_t, c3_t2, -1, 4U,
          c3_b_t > c3_t2))) {
      if (CV_EML_COND(0, 1, 5, CV_RELATIONAL_EVAL(4U, 0U, 6, c3_b_t, c3_t3, -1,
            3U, c3_b_t <= c3_t3))) {
        CV_EML_MCDC(0, 1, 2, true);
        CV_EML_IF(0, 1, 3, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 33);
        c3_b_ss = ((c3_s2 + c3_v2 * (c3_b_t - c3_t2)) + 0.5 * c3_j * c3_T1 *
                   c3_b_mpower(chartInstance, c3_b_t - c3_t2)) -
          0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t - c3_t2);
      } else {
        guard17 = true;
      }
    } else {
      guard17 = true;
    }

    if (guard17 == true) {
      CV_EML_MCDC(0, 1, 2, false);
      CV_EML_IF(0, 1, 3, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 35);
    guard16 = false;
    if (CV_EML_COND(0, 1, 6, CV_RELATIONAL_EVAL(4U, 0U, 7, c3_b_t, c3_t3, -1, 4U,
          c3_b_t > c3_t3))) {
      if (CV_EML_COND(0, 1, 7, CV_RELATIONAL_EVAL(4U, 0U, 8, c3_b_t, c3_t4, -1,
            3U, c3_b_t <= c3_t4))) {
        CV_EML_MCDC(0, 1, 3, true);
        CV_EML_IF(0, 1, 4, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 37);
        c3_b_ss = c3_s3 + c3_v3 * (c3_b_t - c3_t3);
      } else {
        guard16 = true;
      }
    } else {
      guard16 = true;
    }

    if (guard16 == true) {
      CV_EML_MCDC(0, 1, 3, false);
      CV_EML_IF(0, 1, 4, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 39);
    guard15 = false;
    if (CV_EML_COND(0, 1, 8, CV_RELATIONAL_EVAL(4U, 0U, 9, c3_b_t, c3_t4, -1, 4U,
          c3_b_t > c3_t4))) {
      if (CV_EML_COND(0, 1, 9, CV_RELATIONAL_EVAL(4U, 0U, 10, c3_b_t, c3_t5, -1,
            3U, c3_b_t <= c3_t5))) {
        CV_EML_MCDC(0, 1, 4, true);
        CV_EML_IF(0, 1, 5, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 41);
        c3_b_ss = (c3_s4 + c3_v4 * (c3_b_t - c3_t4)) - 0.16666666666666666 *
          c3_j * c3_mpower(chartInstance, c3_b_t - c3_t4);
      } else {
        guard15 = true;
      }
    } else {
      guard15 = true;
    }

    if (guard15 == true) {
      CV_EML_MCDC(0, 1, 4, false);
      CV_EML_IF(0, 1, 5, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 43);
    guard14 = false;
    if (CV_EML_COND(0, 1, 10, CV_RELATIONAL_EVAL(4U, 0U, 11, c3_b_t, c3_t5, -1,
          4U, c3_b_t > c3_t5))) {
      if (CV_EML_COND(0, 1, 11, CV_RELATIONAL_EVAL(4U, 0U, 12, c3_b_t, c3_t6, -1,
            3U, c3_b_t <= c3_t6))) {
        CV_EML_MCDC(0, 1, 5, true);
        CV_EML_IF(0, 1, 6, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 45);
        c3_b_ss = (c3_s5 + c3_v5 * (c3_b_t - c3_t5)) - 0.5 * c3_j * c3_T5 *
          c3_b_mpower(chartInstance, c3_b_t - c3_t5);
      } else {
        guard14 = true;
      }
    } else {
      guard14 = true;
    }

    if (guard14 == true) {
      CV_EML_MCDC(0, 1, 5, false);
      CV_EML_IF(0, 1, 6, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 47);
    guard13 = false;
    if (CV_EML_COND(0, 1, 12, CV_RELATIONAL_EVAL(4U, 0U, 13, c3_b_t, c3_t6, -1,
          4U, c3_b_t > c3_t6))) {
      if (CV_EML_COND(0, 1, 13, CV_RELATIONAL_EVAL(4U, 0U, 14, c3_b_t, c3_t7, -1,
            3U, c3_b_t <= c3_t7))) {
        CV_EML_MCDC(0, 1, 6, true);
        CV_EML_IF(0, 1, 7, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 49);
        c3_b_ss = ((c3_s6 + c3_v6 * (c3_b_t - c3_t6)) - 0.5 * c3_j * c3_T5 *
                   c3_b_mpower(chartInstance, c3_b_t - c3_t6)) +
          0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t - c3_t6);
      } else {
        guard13 = true;
      }
    } else {
      guard13 = true;
    }

    if (guard13 == true) {
      CV_EML_MCDC(0, 1, 6, false);
      CV_EML_IF(0, 1, 7, false);
    }

    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 51);
    if (CV_EML_IF(0, 1, 8, CV_RELATIONAL_EVAL(4U, 0U, 15, c3_b_t, c3_t7, -1, 4U,
          c3_b_t > c3_t7))) {
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 53);
      c3_b_ss = c3_b_u;
    }
  } else {
    _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 57);
    c3_d0 = 2.0 * ((c3_s1 + c3_v1 * c3_T3) + 0.33333333333333331 * c3_j *
                   c3_mpower(chartInstance, c3_T3));
    guard1 = false;
    if (CV_EML_COND(0, 1, 14, CV_RELATIONAL_EVAL(4U, 0U, 16, c3_b_u, c3_d0, -1,
          5U, c3_b_u >= c3_d0))) {
      if (CV_EML_COND(0, 1, 15, CV_RELATIONAL_EVAL(4U, 0U, 17, c3_b_u, 2.0 *
            c3_s3, -1, 2U, c3_b_u < 2.0 * c3_s3))) {
        CV_EML_MCDC(0, 1, 7, true);
        CV_EML_IF(0, 1, 9, true);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 64);
        c3_e_A = -((c3_v1 + c3_b_a * c3_bt) - c3_c_mpower(chartInstance,
                    (((c3_b_a * c3_b_u - 2.0 * c3_b_a * c3_s1) + c3_b_mpower
                      (chartInstance, c3_v1)) + c3_b_mpower(chartInstance,
          c3_b_a) * c3_b_mpower(chartInstance, c3_bt)) - 0.66666666666666663 *
                    c3_b_a * c3_mpower(chartInstance, c3_bt) * c3_j));
        c3_e_B = c3_b_a;
        c3_m_x = c3_e_A;
        c3_n_y = c3_e_B;
        c3_n_x = c3_m_x;
        c3_o_y = c3_n_y;
        c3_o_x = c3_n_x;
        c3_p_y = c3_o_y;
        c3_bt22 = c3_o_x / c3_p_y;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 68);
        c3_t2 = c3_bt22 + c3_t1;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 68);
        c3_t3 = c3_t2 + c3_bt;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 68);
        c3_t4 = c3_t3;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 69);
        c3_t5 = c3_t4 + c3_bt;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 69);
        c3_t6 = c3_t5 + c3_bt22;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 69);
        c3_t7 = c3_t6 + c3_bt;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 70);
        c3_T2 = c3_bt22;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 70);
        c3_T6 = c3_T2;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 71);
        c3_v2 = c3_v1 + c3_j * c3_T1 * c3_T2;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 71);
        c3_s2 = (c3_s1 + c3_v1 * c3_T2) + 0.5 * c3_j * c3_T1 * c3_b_mpower
          (chartInstance, c3_T2);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 72);
        c3_v3 = c3_v2 + 0.5 * c3_j * c3_b_mpower(chartInstance, c3_T1);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 72);
        c3_s3 = (c3_s2 + c3_v2 * c3_T1) + 0.33333333333333331 * c3_j * c3_mpower
          (chartInstance, c3_T1);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 74);
        c3_v4 = c3_v3;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 74);
        c3_s4 = c3_s3;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 75);
        c3_v5 = c3_v4 - 0.5 * c3_j * c3_b_mpower(chartInstance, c3_T5);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 75);
        c3_s5 = (c3_s4 + c3_v4 * c3_T5) - 0.16666666666666666 * c3_j * c3_mpower
          (chartInstance, c3_T5);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 76);
        c3_v6 = c3_v5 - c3_j * c3_T5 * c3_T6;
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 76);
        c3_s6 = (c3_s5 + c3_v5 * c3_T6) - 0.5 * c3_j * c3_T5 * c3_b_mpower
          (chartInstance, c3_T6);
        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 79);
        guard7 = false;
        if (CV_EML_COND(0, 1, 16, CV_RELATIONAL_EVAL(4U, 0U, 18, c3_b_t, 0.0, -1,
              4U, c3_b_t > 0.0))) {
          if (CV_EML_COND(0, 1, 17, CV_RELATIONAL_EVAL(4U, 0U, 19, c3_b_t, c3_t1,
                -1, 3U, c3_b_t <= c3_t1))) {
            CV_EML_MCDC(0, 1, 8, true);
            CV_EML_IF(0, 1, 10, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 81);
            c3_b_ss = 0.16666666666666666 * c3_j * c3_mpower(chartInstance,
              c3_b_t);
          } else {
            guard7 = true;
          }
        } else {
          guard7 = true;
        }

        if (guard7 == true) {
          CV_EML_MCDC(0, 1, 8, false);
          CV_EML_IF(0, 1, 10, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 83);
        guard6 = false;
        if (CV_EML_COND(0, 1, 18, CV_RELATIONAL_EVAL(4U, 0U, 20, c3_b_t, c3_t1,
              -1, 4U, c3_b_t > c3_t1))) {
          if (CV_EML_COND(0, 1, 19, CV_RELATIONAL_EVAL(4U, 0U, 21, c3_b_t, c3_t2,
                -1, 3U, c3_b_t <= c3_t2))) {
            CV_EML_MCDC(0, 1, 9, true);
            CV_EML_IF(0, 1, 11, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 85);
            c3_b_ss = (c3_s1 + c3_v1 * (c3_b_t - c3_t1)) + 0.5 * c3_j * c3_T1 *
              c3_b_mpower(chartInstance, c3_b_t - c3_t1);
          } else {
            guard6 = true;
          }
        } else {
          guard6 = true;
        }

        if (guard6 == true) {
          CV_EML_MCDC(0, 1, 9, false);
          CV_EML_IF(0, 1, 11, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 87);
        guard5 = false;
        if (CV_EML_COND(0, 1, 20, CV_RELATIONAL_EVAL(4U, 0U, 22, c3_b_t, c3_t2,
              -1, 4U, c3_b_t > c3_t2))) {
          if (CV_EML_COND(0, 1, 21, CV_RELATIONAL_EVAL(4U, 0U, 23, c3_b_t, c3_t3,
                -1, 3U, c3_b_t <= c3_t3))) {
            CV_EML_MCDC(0, 1, 10, true);
            CV_EML_IF(0, 1, 12, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 89);
            c3_b_ss = ((c3_s2 + c3_v2 * (c3_b_t - c3_t2)) + 0.5 * c3_j * c3_T1 *
                       c3_b_mpower(chartInstance, c3_b_t - c3_t2)) -
              0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t -
              c3_t2);
          } else {
            guard5 = true;
          }
        } else {
          guard5 = true;
        }

        if (guard5 == true) {
          CV_EML_MCDC(0, 1, 10, false);
          CV_EML_IF(0, 1, 12, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 92);
        guard4 = false;
        if (CV_EML_COND(0, 1, 22, CV_RELATIONAL_EVAL(4U, 0U, 24, c3_b_t, c3_t4,
              -1, 4U, c3_b_t > c3_t4))) {
          if (CV_EML_COND(0, 1, 23, CV_RELATIONAL_EVAL(4U, 0U, 25, c3_b_t, c3_t5,
                -1, 3U, c3_b_t <= c3_t5))) {
            CV_EML_MCDC(0, 1, 11, true);
            CV_EML_IF(0, 1, 13, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 94);
            c3_b_ss = (c3_s4 + c3_v4 * (c3_b_t - c3_t4)) - 0.16666666666666666 *
              c3_j * c3_mpower(chartInstance, c3_b_t - c3_t4);
          } else {
            guard4 = true;
          }
        } else {
          guard4 = true;
        }

        if (guard4 == true) {
          CV_EML_MCDC(0, 1, 11, false);
          CV_EML_IF(0, 1, 13, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 96);
        guard3 = false;
        if (CV_EML_COND(0, 1, 24, CV_RELATIONAL_EVAL(4U, 0U, 26, c3_b_t, c3_t5,
              -1, 4U, c3_b_t > c3_t5))) {
          if (CV_EML_COND(0, 1, 25, CV_RELATIONAL_EVAL(4U, 0U, 27, c3_b_t, c3_t6,
                -1, 3U, c3_b_t <= c3_t6))) {
            CV_EML_MCDC(0, 1, 12, true);
            CV_EML_IF(0, 1, 14, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 97);
            c3_b_v = c3_v5 - 0.5 * c3_j * 10.0 * (c3_b_t - c3_t5);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 98);
            c3_b_ss = (c3_s5 + c3_v5 * (c3_b_t - c3_t5)) - 0.5 * c3_j * c3_T5 *
              c3_b_mpower(chartInstance, c3_b_t - c3_t5);
          } else {
            guard3 = true;
          }
        } else {
          guard3 = true;
        }

        if (guard3 == true) {
          CV_EML_MCDC(0, 1, 12, false);
          CV_EML_IF(0, 1, 14, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 100);
        guard2 = false;
        if (CV_EML_COND(0, 1, 26, CV_RELATIONAL_EVAL(4U, 0U, 28, c3_b_t, c3_t6,
              -1, 4U, c3_b_t > c3_t6))) {
          if (CV_EML_COND(0, 1, 27, CV_RELATIONAL_EVAL(4U, 0U, 29, c3_b_t, c3_t7,
                -1, 3U, c3_b_t <= c3_t7))) {
            CV_EML_MCDC(0, 1, 13, true);
            CV_EML_IF(0, 1, 15, true);
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 102);
            c3_b_ss = ((c3_s6 + c3_v6 * (c3_b_t - c3_t6)) - 0.5 * c3_j * c3_T5 *
                       c3_b_mpower(chartInstance, c3_b_t - c3_t6)) +
              0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t -
              c3_t6);
          } else {
            guard2 = true;
          }
        } else {
          guard2 = true;
        }

        if (guard2 == true) {
          CV_EML_MCDC(0, 1, 13, false);
          CV_EML_IF(0, 1, 15, false);
        }

        _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 104);
        if (CV_EML_IF(0, 1, 16, CV_RELATIONAL_EVAL(4U, 0U, 30, c3_b_t, c3_t7, -1,
              4U, c3_b_t > c3_t7))) {
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 105);
          c3_b_v = 0.0;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 106);
          c3_b_ss = c3_b_u;
        }
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1 == true) {
      CV_EML_MCDC(0, 1, 7, false);
      CV_EML_IF(0, 1, 9, false);
      _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 109);
      c3_d1 = 2.0 * ((c3_s1 + c3_v1 * c3_T3) + 0.33333333333333331 * c3_j *
                     c3_mpower(chartInstance, c3_T3));
      guard8 = false;
      if (CV_EML_COND(0, 1, 28, CV_RELATIONAL_EVAL(4U, 0U, 31, c3_b_u, c3_d1, -1,
            2U, c3_b_u < c3_d1))) {
        if (CV_EML_COND(0, 1, 29, CV_RELATIONAL_EVAL(4U, 0U, 32, c3_b_u, 0.0, -1,
              4U, c3_b_u > 0.0))) {
          CV_EML_MCDC(0, 1, 14, true);
          CV_EML_IF(0, 1, 17, true);
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 110);
          c3_f_A = c3_b_u;
          c3_f_B = 2.0 * c3_j;
          c3_p_x = c3_f_A;
          c3_q_y = c3_f_B;
          c3_q_x = c3_p_x;
          c3_r_y = c3_q_y;
          c3_r_x = c3_q_x;
          c3_s_y = c3_r_y;
          c3_t_y = c3_r_x / c3_s_y;
          c3_bt33 = c3_d_mpower(chartInstance, c3_t_y);
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 111);
          c3_T1 = c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 111);
          c3_T2 = c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 111);
          c3_T3 = c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 111);
          c3_T4 = c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 112);
          c3_t1 = c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 113);
          c3_t2 = c3_bt33 + c3_t1;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 113);
          c3_t3 = c3_bt33 + c3_t2;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 113);
          c3_t4 = c3_bt33 + c3_t3;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 114);
          c3_v1 = 0.5 * c3_j * c3_bt33 * c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 114);
          c3_s1 = 0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_bt33);
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 115);
          c3_v2 = c3_j * c3_bt33 * c3_bt33;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 115);
          c3_s2 = 0.5 * c3_b_u;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 115);
          c3_s3 = c3_b_u - c3_s1;
          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 118);
          guard12 = false;
          if (CV_EML_COND(0, 1, 30, CV_RELATIONAL_EVAL(4U, 0U, 33, c3_b_t, 0.0,
                -1, 4U, c3_b_t > 0.0))) {
            if (CV_EML_COND(0, 1, 31, CV_RELATIONAL_EVAL(4U, 0U, 34, c3_b_t,
                  c3_t1, -1, 3U, c3_b_t <= c3_t1))) {
              CV_EML_MCDC(0, 1, 15, true);
              CV_EML_IF(0, 1, 18, true);
              _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 119);
              c3_b_ss = 0.16666666666666666 * c3_j * c3_mpower(chartInstance,
                c3_b_t);
            } else {
              guard12 = true;
            }
          } else {
            guard12 = true;
          }

          if (guard12 == true) {
            CV_EML_MCDC(0, 1, 15, false);
            CV_EML_IF(0, 1, 18, false);
          }

          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 121);
          guard11 = false;
          if (CV_EML_COND(0, 1, 32, CV_RELATIONAL_EVAL(4U, 0U, 35, c3_b_t, c3_t1,
                -1, 4U, c3_b_t > c3_t1))) {
            if (CV_EML_COND(0, 1, 33, CV_RELATIONAL_EVAL(4U, 0U, 36, c3_b_t,
                  c3_t2, -1, 3U, c3_b_t <= c3_t2))) {
              CV_EML_MCDC(0, 1, 16, true);
              CV_EML_IF(0, 1, 19, true);
              _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 123);
              c3_b_ss = ((c3_s1 + c3_v1 * (c3_b_t - c3_t1)) + 0.5 * c3_j *
                         c3_bt33 * c3_b_mpower(chartInstance, c3_b_t - c3_t1)) -
                0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t -
                c3_t1);
            } else {
              guard11 = true;
            }
          } else {
            guard11 = true;
          }

          if (guard11 == true) {
            CV_EML_MCDC(0, 1, 16, false);
            CV_EML_IF(0, 1, 19, false);
          }

          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 128U);
          guard10 = false;
          if (CV_EML_COND(0, 1, 34, CV_RELATIONAL_EVAL(4U, 0U, 37, c3_b_t, c3_t2,
                -1, 4U, c3_b_t > c3_t2))) {
            if (CV_EML_COND(0, 1, 35, CV_RELATIONAL_EVAL(4U, 0U, 38, c3_b_t,
                  c3_t3, -1, 3U, c3_b_t <= c3_t3))) {
              CV_EML_MCDC(0, 1, 17, true);
              CV_EML_IF(0, 1, 20, true);
              _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 130U);
              c3_b_ss = (c3_s2 + c3_v2 * (c3_b_t - c3_t2)) - 0.16666666666666666
                * c3_j * c3_mpower(chartInstance, c3_b_t - c3_t2);
            } else {
              guard10 = true;
            }
          } else {
            guard10 = true;
          }

          if (guard10 == true) {
            CV_EML_MCDC(0, 1, 17, false);
            CV_EML_IF(0, 1, 20, false);
          }

          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 133U);
          guard9 = false;
          if (CV_EML_COND(0, 1, 36, CV_RELATIONAL_EVAL(4U, 0U, 39, c3_b_t, c3_t3,
                -1, 4U, c3_b_t > c3_t3))) {
            if (CV_EML_COND(0, 1, 37, CV_RELATIONAL_EVAL(4U, 0U, 40, c3_b_t,
                  c3_t4, -1, 3U, c3_b_t <= c3_t4))) {
              CV_EML_MCDC(0, 1, 18, true);
              CV_EML_IF(0, 1, 21, true);
              _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 135U);
              c3_b_ss = ((c3_s3 + c3_v1 * (c3_b_t - c3_t3)) - 0.5 * c3_j *
                         c3_bt33 * c3_b_mpower(chartInstance, c3_b_t - c3_t3)) +
                0.16666666666666666 * c3_j * c3_mpower(chartInstance, c3_b_t -
                c3_t3);
            } else {
              guard9 = true;
            }
          } else {
            guard9 = true;
          }

          if (guard9 == true) {
            CV_EML_MCDC(0, 1, 18, false);
            CV_EML_IF(0, 1, 21, false);
          }

          _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 137U);
          if (CV_EML_IF(0, 1, 22, CV_RELATIONAL_EVAL(4U, 0U, 41, c3_b_t, c3_t4,
                -1, 4U, c3_b_t > c3_t4))) {
            _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, 138U);
            c3_b_ss = c3_b_u;
          }
        } else {
          guard8 = true;
        }
      } else {
        guard8 = true;
      }

      if (guard8 == true) {
        CV_EML_MCDC(0, 1, 14, false);
        CV_EML_IF(0, 1, 17, false);
      }
    }
  }

  _SFD_EML_CALL(0U, chartInstance->c3_sfEvent, -138);
  _SFD_SYMBOL_SCOPE_POP();
  *chartInstance->c3_ss = c3_b_ss;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, chartInstance->c3_sfEvent);
}

static void initSimStructsc3_onetwo(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_script_number_translation(uint32_T c3_machineNumber, uint32_T
  c3_chartNumber, uint32_T c3_instanceNumber)
{
  (void)c3_machineNumber;
  (void)c3_chartNumber;
  (void)c3_instanceNumber;
}

static const mxArray *c3_sf_marshallOut(void *chartInstanceVoid, void *c3_inData)
{
  const mxArray *c3_mxArrayOutData = NULL;
  real_T c3_b_u;
  const mxArray *c3_y = NULL;
  SFc3_onetwoInstanceStruct *chartInstance;
  chartInstance = (SFc3_onetwoInstanceStruct *)chartInstanceVoid;
  c3_mxArrayOutData = NULL;
  c3_b_u = *(real_T *)c3_inData;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_b_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c3_mxArrayOutData, c3_y, false);
  return c3_mxArrayOutData;
}

static real_T c3_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_ss, const char_T *c3_identifier)
{
  real_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_ss), &c3_thisId);
  sf_mex_destroy(&c3_b_ss);
  return c3_y;
}

static real_T c3_b_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId)
{
  real_T c3_y;
  real_T c3_d2;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_b_u), &c3_d2, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d2;
  sf_mex_destroy(&c3_b_u);
  return c3_y;
}

static void c3_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData)
{
  const mxArray *c3_b_ss;
  const char_T *c3_identifier;
  emlrtMsgIdentifier c3_thisId;
  real_T c3_y;
  SFc3_onetwoInstanceStruct *chartInstance;
  chartInstance = (SFc3_onetwoInstanceStruct *)chartInstanceVoid;
  c3_b_ss = sf_mex_dup(c3_mxArrayInData);
  c3_identifier = c3_varName;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_ss), &c3_thisId);
  sf_mex_destroy(&c3_b_ss);
  *(real_T *)c3_outData = c3_y;
  sf_mex_destroy(&c3_mxArrayInData);
}

const mxArray *sf_c3_onetwo_get_eml_resolved_functions_info(void)
{
  const mxArray *c3_nameCaptureInfo = NULL;
  c3_nameCaptureInfo = NULL;
  sf_mex_assign(&c3_nameCaptureInfo, sf_mex_createstruct("structure", 2, 24, 1),
                false);
  c3_info_helper(&c3_nameCaptureInfo);
  sf_mex_emlrtNameCapturePostProcessR2012a(&c3_nameCaptureInfo);
  return c3_nameCaptureInfo;
}

static void c3_info_helper(const mxArray **c3_info)
{
  const mxArray *c3_rhs0 = NULL;
  const mxArray *c3_lhs0 = NULL;
  const mxArray *c3_rhs1 = NULL;
  const mxArray *c3_lhs1 = NULL;
  const mxArray *c3_rhs2 = NULL;
  const mxArray *c3_lhs2 = NULL;
  const mxArray *c3_rhs3 = NULL;
  const mxArray *c3_lhs3 = NULL;
  const mxArray *c3_rhs4 = NULL;
  const mxArray *c3_lhs4 = NULL;
  const mxArray *c3_rhs5 = NULL;
  const mxArray *c3_lhs5 = NULL;
  const mxArray *c3_rhs6 = NULL;
  const mxArray *c3_lhs6 = NULL;
  const mxArray *c3_rhs7 = NULL;
  const mxArray *c3_lhs7 = NULL;
  const mxArray *c3_rhs8 = NULL;
  const mxArray *c3_lhs8 = NULL;
  const mxArray *c3_rhs9 = NULL;
  const mxArray *c3_lhs9 = NULL;
  const mxArray *c3_rhs10 = NULL;
  const mxArray *c3_lhs10 = NULL;
  const mxArray *c3_rhs11 = NULL;
  const mxArray *c3_lhs11 = NULL;
  const mxArray *c3_rhs12 = NULL;
  const mxArray *c3_lhs12 = NULL;
  const mxArray *c3_rhs13 = NULL;
  const mxArray *c3_lhs13 = NULL;
  const mxArray *c3_rhs14 = NULL;
  const mxArray *c3_lhs14 = NULL;
  const mxArray *c3_rhs15 = NULL;
  const mxArray *c3_lhs15 = NULL;
  const mxArray *c3_rhs16 = NULL;
  const mxArray *c3_lhs16 = NULL;
  const mxArray *c3_rhs17 = NULL;
  const mxArray *c3_lhs17 = NULL;
  const mxArray *c3_rhs18 = NULL;
  const mxArray *c3_lhs18 = NULL;
  const mxArray *c3_rhs19 = NULL;
  const mxArray *c3_lhs19 = NULL;
  const mxArray *c3_rhs20 = NULL;
  const mxArray *c3_lhs20 = NULL;
  const mxArray *c3_rhs21 = NULL;
  const mxArray *c3_lhs21 = NULL;
  const mxArray *c3_rhs22 = NULL;
  const mxArray *c3_lhs22 = NULL;
  const mxArray *c3_rhs23 = NULL;
  const mxArray *c3_lhs23 = NULL;
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(""), "context", "context", 0);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("mrdivide"), "name", "name", 0);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 0);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "resolved",
                  "resolved", 0);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1410786048U), "fileTimeLo",
                  "fileTimeLo", 0);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 0);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1369988286U), "mFileTimeLo",
                  "mFileTimeLo", 0);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 0);
  sf_mex_assign(&c3_rhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs0, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs0), "rhs", "rhs", 0);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs0), "lhs", "lhs", 0);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "context",
                  "context", 1);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("coder.internal.assert"),
                  "name", "name", 1);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 1);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/assert.m"),
                  "resolved", "resolved", 1);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1389692574U), "fileTimeLo",
                  "fileTimeLo", 1);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 1);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 1);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 1);
  sf_mex_assign(&c3_rhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs1, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs1), "rhs", "rhs", 1);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs1), "lhs", "lhs", 1);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p"), "context",
                  "context", 2);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("rdivide"), "name", "name", 2);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 2);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "resolved",
                  "resolved", 2);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1363688680U), "fileTimeLo",
                  "fileTimeLo", 2);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 2);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 2);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 2);
  sf_mex_assign(&c3_rhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs2, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs2), "rhs", "rhs", 2);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs2), "lhs", "lhs", 2);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 3);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 3);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 3);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 3);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1395906656U), "fileTimeLo",
                  "fileTimeLo", 3);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 3);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 3);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 3);
  sf_mex_assign(&c3_rhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs3, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs3), "rhs", "rhs", 3);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs3), "lhs", "lhs", 3);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 4);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalexp_compatible"),
                  "name", "name", 4);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 4);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_compatible.m"),
                  "resolved", "resolved", 4);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1286797196U), "fileTimeLo",
                  "fileTimeLo", 4);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 4);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 4);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 4);
  sf_mex_assign(&c3_rhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs4, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs4), "rhs", "rhs", 4);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs4), "lhs", "lhs", 4);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m"), "context",
                  "context", 5);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_div"), "name", "name", 5);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 5);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m"), "resolved",
                  "resolved", 5);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1386398752U), "fileTimeLo",
                  "fileTimeLo", 5);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 5);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 5);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 5);
  sf_mex_assign(&c3_rhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs5, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs5), "rhs", "rhs", 5);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs5), "lhs", "lhs", 5);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m"), "context",
                  "context", 6);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("coder.internal.div"), "name",
                  "name", 6);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 6);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/div.p"), "resolved",
                  "resolved", 6);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1410786170U), "fileTimeLo",
                  "fileTimeLo", 6);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 6);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 6);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 6);
  sf_mex_assign(&c3_rhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs6, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs6), "rhs", "rhs", 6);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs6), "lhs", "lhs", 6);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(""), "context", "context", 7);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("mpower"), "name", "name", 7);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 7);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m"), "resolved",
                  "resolved", 7);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1363688678U), "fileTimeLo",
                  "fileTimeLo", 7);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 7);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 7);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 7);
  sf_mex_assign(&c3_rhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs7, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs7), "rhs", "rhs", 7);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs7), "lhs", "lhs", 7);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m"), "context",
                  "context", 8);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 8);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 8);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 8);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1395906656U), "fileTimeLo",
                  "fileTimeLo", 8);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 8);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 8);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 8);
  sf_mex_assign(&c3_rhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs8, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs8), "rhs", "rhs", 8);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs8), "lhs", "lhs", 8);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m"), "context",
                  "context", 9);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("ismatrix"), "name", "name", 9);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 9);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elmat/ismatrix.m"), "resolved",
                  "resolved", 9);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1331279658U), "fileTimeLo",
                  "fileTimeLo", 9);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 9);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 9);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 9);
  sf_mex_assign(&c3_rhs9, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs9, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs9), "rhs", "rhs", 9);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs9), "lhs", "lhs", 9);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mpower.m"), "context",
                  "context", 10);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("power"), "name", "name", 10);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 10);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m"), "resolved",
                  "resolved", 10);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1395303306U), "fileTimeLo",
                  "fileTimeLo", 10);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 10);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 10);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 10);
  sf_mex_assign(&c3_rhs10, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs10, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs10), "rhs", "rhs",
                  10);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs10), "lhs", "lhs",
                  10);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m"), "context",
                  "context", 11);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 11);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 11);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 11);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1395906656U), "fileTimeLo",
                  "fileTimeLo", 11);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 11);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 11);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 11);
  sf_mex_assign(&c3_rhs11, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs11, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs11), "rhs", "rhs",
                  11);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs11), "lhs", "lhs",
                  11);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower"), "context",
                  "context", 12);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 12);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 12);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 12);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1375959088U), "fileTimeLo",
                  "fileTimeLo", 12);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 12);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 12);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 12);
  sf_mex_assign(&c3_rhs12, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs12, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs12), "rhs", "rhs",
                  12);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs12), "lhs", "lhs",
                  12);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "context",
                  "context", 13);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("coder.internal.scalarEg"),
                  "name", "name", 13);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 13);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalarEg.p"),
                  "resolved", "resolved", 13);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1410786170U), "fileTimeLo",
                  "fileTimeLo", 13);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 13);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 13);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 13);
  sf_mex_assign(&c3_rhs13, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs13, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs13), "rhs", "rhs",
                  13);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs13), "lhs", "lhs",
                  13);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower"), "context",
                  "context", 14);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalexp_alloc"), "name",
                  "name", 14);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 14);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m"),
                  "resolved", "resolved", 14);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1375959088U), "fileTimeLo",
                  "fileTimeLo", 14);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 14);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 14);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 14);
  sf_mex_assign(&c3_rhs14, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs14, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs14), "rhs", "rhs",
                  14);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs14), "lhs", "lhs",
                  14);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalexp_alloc.m"),
                  "context", "context", 15);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("coder.internal.scalexpAlloc"),
                  "name", "name", 15);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 15);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/coder/coder/+coder/+internal/scalexpAlloc.p"),
                  "resolved", "resolved", 15);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1410786170U), "fileTimeLo",
                  "fileTimeLo", 15);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 15);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 15);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 15);
  sf_mex_assign(&c3_rhs15, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs15, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs15), "rhs", "rhs",
                  15);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs15), "lhs", "lhs",
                  15);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower"), "context",
                  "context", 16);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("floor"), "name", "name", 16);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 16);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m"), "resolved",
                  "resolved", 16);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1363688654U), "fileTimeLo",
                  "fileTimeLo", 16);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 16);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 16);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 16);
  sf_mex_assign(&c3_rhs16, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs16, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs16), "rhs", "rhs",
                  16);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs16), "lhs", "lhs",
                  16);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m"), "context",
                  "context", 17);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "coder.internal.isBuiltInNumeric"), "name", "name", 17);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 17);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/shared/coder/coder/+coder/+internal/isBuiltInNumeric.m"),
                  "resolved", "resolved", 17);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1395906656U), "fileTimeLo",
                  "fileTimeLo", 17);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 17);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 17);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 17);
  sf_mex_assign(&c3_rhs17, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs17, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs17), "rhs", "rhs",
                  17);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs17), "lhs", "lhs",
                  17);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/floor.m"), "context",
                  "context", 18);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalar_floor"), "name",
                  "name", 18);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 18);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_floor.m"),
                  "resolved", "resolved", 18);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1286797126U), "fileTimeLo",
                  "fileTimeLo", 18);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 18);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 18);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 18);
  sf_mex_assign(&c3_rhs18, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs18, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs18), "rhs", "rhs",
                  18);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs18), "lhs", "lhs",
                  18);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power"),
                  "context", "context", 19);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalar_eg"), "name",
                  "name", 19);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 19);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_scalar_eg.m"), "resolved",
                  "resolved", 19);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1375959088U), "fileTimeLo",
                  "fileTimeLo", 19);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 19);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 19);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 19);
  sf_mex_assign(&c3_rhs19, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs19, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs19), "rhs", "rhs",
                  19);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs19), "lhs", "lhs",
                  19);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!fltpower"), "context",
                  "context", 20);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_error"), "name", "name",
                  20);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 20);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m"), "resolved",
                  "resolved", 20);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1343808758U), "fileTimeLo",
                  "fileTimeLo", 20);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 20);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 20);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 20);
  sf_mex_assign(&c3_rhs20, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs20, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs20), "rhs", "rhs",
                  20);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs20), "lhs", "lhs",
                  20);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/power.m!scalar_float_power"),
                  "context", "context", 21);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("sqrt"), "name", "name", 21);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 21);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m"), "resolved",
                  "resolved", 21);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1343808786U), "fileTimeLo",
                  "fileTimeLo", 21);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 21);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 21);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 21);
  sf_mex_assign(&c3_rhs21, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs21, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs21), "rhs", "rhs",
                  21);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs21), "lhs", "lhs",
                  21);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m"), "context",
                  "context", 22);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_error"), "name", "name",
                  22);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("char"), "dominantType",
                  "dominantType", 22);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_error.m"), "resolved",
                  "resolved", 22);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1343808758U), "fileTimeLo",
                  "fileTimeLo", 22);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 22);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 22);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 22);
  sf_mex_assign(&c3_rhs22, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs22, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs22), "rhs", "rhs",
                  22);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs22), "lhs", "lhs",
                  22);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/sqrt.m"), "context",
                  "context", 23);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("eml_scalar_sqrt"), "name",
                  "name", 23);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut("double"), "dominantType",
                  "dominantType", 23);
  sf_mex_addfield(*c3_info, c3_emlrt_marshallOut(
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/elfun/eml_scalar_sqrt.m"),
                  "resolved", "resolved", 23);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(1286797138U), "fileTimeLo",
                  "fileTimeLo", 23);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "fileTimeHi",
                  "fileTimeHi", 23);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeLo",
                  "mFileTimeLo", 23);
  sf_mex_addfield(*c3_info, c3_b_emlrt_marshallOut(0U), "mFileTimeHi",
                  "mFileTimeHi", 23);
  sf_mex_assign(&c3_rhs23, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_assign(&c3_lhs23, sf_mex_createcellmatrix(0, 1), false);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_rhs23), "rhs", "rhs",
                  23);
  sf_mex_addfield(*c3_info, sf_mex_duplicatearraysafe(&c3_lhs23), "lhs", "lhs",
                  23);
  sf_mex_destroy(&c3_rhs0);
  sf_mex_destroy(&c3_lhs0);
  sf_mex_destroy(&c3_rhs1);
  sf_mex_destroy(&c3_lhs1);
  sf_mex_destroy(&c3_rhs2);
  sf_mex_destroy(&c3_lhs2);
  sf_mex_destroy(&c3_rhs3);
  sf_mex_destroy(&c3_lhs3);
  sf_mex_destroy(&c3_rhs4);
  sf_mex_destroy(&c3_lhs4);
  sf_mex_destroy(&c3_rhs5);
  sf_mex_destroy(&c3_lhs5);
  sf_mex_destroy(&c3_rhs6);
  sf_mex_destroy(&c3_lhs6);
  sf_mex_destroy(&c3_rhs7);
  sf_mex_destroy(&c3_lhs7);
  sf_mex_destroy(&c3_rhs8);
  sf_mex_destroy(&c3_lhs8);
  sf_mex_destroy(&c3_rhs9);
  sf_mex_destroy(&c3_lhs9);
  sf_mex_destroy(&c3_rhs10);
  sf_mex_destroy(&c3_lhs10);
  sf_mex_destroy(&c3_rhs11);
  sf_mex_destroy(&c3_lhs11);
  sf_mex_destroy(&c3_rhs12);
  sf_mex_destroy(&c3_lhs12);
  sf_mex_destroy(&c3_rhs13);
  sf_mex_destroy(&c3_lhs13);
  sf_mex_destroy(&c3_rhs14);
  sf_mex_destroy(&c3_lhs14);
  sf_mex_destroy(&c3_rhs15);
  sf_mex_destroy(&c3_lhs15);
  sf_mex_destroy(&c3_rhs16);
  sf_mex_destroy(&c3_lhs16);
  sf_mex_destroy(&c3_rhs17);
  sf_mex_destroy(&c3_lhs17);
  sf_mex_destroy(&c3_rhs18);
  sf_mex_destroy(&c3_lhs18);
  sf_mex_destroy(&c3_rhs19);
  sf_mex_destroy(&c3_lhs19);
  sf_mex_destroy(&c3_rhs20);
  sf_mex_destroy(&c3_lhs20);
  sf_mex_destroy(&c3_rhs21);
  sf_mex_destroy(&c3_lhs21);
  sf_mex_destroy(&c3_rhs22);
  sf_mex_destroy(&c3_lhs22);
  sf_mex_destroy(&c3_rhs23);
  sf_mex_destroy(&c3_lhs23);
}

static const mxArray *c3_emlrt_marshallOut(const char * c3_b_u)
{
  const mxArray *c3_y = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", c3_b_u, 15, 0U, 0U, 0U, 2, 1, strlen
    (c3_b_u)), false);
  return c3_y;
}

static const mxArray *c3_b_emlrt_marshallOut(const uint32_T c3_b_u)
{
  const mxArray *c3_y = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_b_u, 7, 0U, 0U, 0U, 0), false);
  return c3_y;
}

static real_T c3_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T c3_b_a)
{
  real_T c3_c_a;
  real_T c3_d_a;
  real_T c3_ak;
  real_T c3_e_a;
  real_T c3_ar;
  c3_c_a = c3_b_a;
  c3_d_a = c3_c_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_d_a;
  c3_e_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  c3_ar = c3_e_a;
  return muDoubleScalarPower(c3_ar, 3.0);
}

static void c3_eml_scalar_eg(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static real_T c3_b_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a)
{
  real_T c3_c_a;
  real_T c3_d_a;
  real_T c3_ak;
  real_T c3_e_a;
  c3_c_a = c3_b_a;
  c3_d_a = c3_c_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_d_a;
  c3_e_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  return c3_e_a * c3_e_a;
}

static real_T c3_c_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a)
{
  real_T c3_c;
  real_T c3_c_a;
  real_T c3_d_a;
  real_T c3_ak;
  real_T c3_e_a;
  real_T c3_x;
  c3_c_a = c3_b_a;
  c3_d_a = c3_c_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_d_a;
  if (c3_ak < 0.0) {
    c3_eml_error(chartInstance);
  }

  c3_e_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  c3_x = c3_e_a;
  c3_c = c3_x;
  if (c3_c < 0.0) {
    c3_b_eml_error(chartInstance);
  }

  return muDoubleScalarSqrt(c3_c);
}

static void c3_eml_error(SFc3_onetwoInstanceStruct *chartInstance)
{
  int32_T c3_i0;
  static char_T c3_cv0[31] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'p', 'o', 'w', 'e', 'r', '_', 'd', 'o', 'm', 'a', 'i',
    'n', 'E', 'r', 'r', 'o', 'r' };

  char_T c3_b_u[31];
  const mxArray *c3_y = NULL;
  (void)chartInstance;
  for (c3_i0 = 0; c3_i0 < 31; c3_i0++) {
    c3_b_u[c3_i0] = c3_cv0[c3_i0];
  }

  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", c3_b_u, 10, 0U, 1U, 0U, 2, 1, 31),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message", 1U,
    1U, 14, c3_y));
}

static void c3_b_eml_error(SFc3_onetwoInstanceStruct *chartInstance)
{
  int32_T c3_i1;
  static char_T c3_cv1[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  char_T c3_b_u[30];
  const mxArray *c3_y = NULL;
  int32_T c3_i2;
  static char_T c3_cv2[4] = { 's', 'q', 'r', 't' };

  char_T c3_c_u[4];
  const mxArray *c3_b_y = NULL;
  (void)chartInstance;
  for (c3_i1 = 0; c3_i1 < 30; c3_i1++) {
    c3_b_u[c3_i1] = c3_cv1[c3_i1];
  }

  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", c3_b_u, 10, 0U, 1U, 0U, 2, 1, 30),
                false);
  for (c3_i2 = 0; c3_i2 < 4; c3_i2++) {
    c3_c_u[c3_i2] = c3_cv2[c3_i2];
  }

  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", c3_c_u, 10, 0U, 1U, 0U, 2, 1, 4),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message", 1U,
    2U, 14, c3_y, 14, c3_b_y));
}

static real_T c3_d_mpower(SFc3_onetwoInstanceStruct *chartInstance, real_T
  c3_b_a)
{
  real_T c3_c_a;
  real_T c3_d_a;
  real_T c3_ak;
  real_T c3_e_a;
  real_T c3_ar;
  c3_c_a = c3_b_a;
  c3_d_a = c3_c_a;
  c3_eml_scalar_eg(chartInstance);
  c3_ak = c3_d_a;
  if (c3_ak < 0.0) {
    c3_eml_error(chartInstance);
  }

  c3_e_a = c3_ak;
  c3_eml_scalar_eg(chartInstance);
  c3_ar = c3_e_a;
  return muDoubleScalarPower(c3_ar, 0.33333333333333331);
}

static const mxArray *c3_b_sf_marshallOut(void *chartInstanceVoid, void
  *c3_inData)
{
  const mxArray *c3_mxArrayOutData = NULL;
  int32_T c3_b_u;
  const mxArray *c3_y = NULL;
  SFc3_onetwoInstanceStruct *chartInstance;
  chartInstance = (SFc3_onetwoInstanceStruct *)chartInstanceVoid;
  c3_mxArrayOutData = NULL;
  c3_b_u = *(int32_T *)c3_inData;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_create("y", &c3_b_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c3_mxArrayOutData, c3_y, false);
  return c3_mxArrayOutData;
}

static int32_T c3_c_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId)
{
  int32_T c3_y;
  int32_T c3_i3;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_b_u), &c3_i3, 1, 6, 0U, 0, 0U, 0);
  c3_y = c3_i3;
  sf_mex_destroy(&c3_b_u);
  return c3_y;
}

static void c3_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c3_mxArrayInData, const char_T *c3_varName, void *c3_outData)
{
  const mxArray *c3_b_sfEvent;
  const char_T *c3_identifier;
  emlrtMsgIdentifier c3_thisId;
  int32_T c3_y;
  SFc3_onetwoInstanceStruct *chartInstance;
  chartInstance = (SFc3_onetwoInstanceStruct *)chartInstanceVoid;
  c3_b_sfEvent = sf_mex_dup(c3_mxArrayInData);
  c3_identifier = c3_varName;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_sfEvent),
    &c3_thisId);
  sf_mex_destroy(&c3_b_sfEvent);
  *(int32_T *)c3_outData = c3_y;
  sf_mex_destroy(&c3_mxArrayInData);
}

static uint8_T c3_d_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_is_active_c3_onetwo, const char_T *c3_identifier)
{
  uint8_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = c3_identifier;
  c3_thisId.fParent = NULL;
  c3_y = c3_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c3_b_is_active_c3_onetwo), &c3_thisId);
  sf_mex_destroy(&c3_b_is_active_c3_onetwo);
  return c3_y;
}

static uint8_T c3_e_emlrt_marshallIn(SFc3_onetwoInstanceStruct *chartInstance,
  const mxArray *c3_b_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint8_T c3_y;
  uint8_T c3_u0;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_b_u), &c3_u0, 1, 3, 0U, 0, 0U, 0);
  c3_y = c3_u0;
  sf_mex_destroy(&c3_b_u);
  return c3_y;
}

static void init_dsm_address_info(SFc3_onetwoInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc3_onetwoInstanceStruct *chartInstance)
{
  chartInstance->c3_u = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    0);
  chartInstance->c3_a = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    1);
  chartInstance->c3_v = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    2);
  chartInstance->c3_ss = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c3_t = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    3);
  chartInstance->c3_J = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    4);
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c3_onetwo_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3884139477U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3243415781U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(496654948U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(148657381U);
}

mxArray* sf_c3_onetwo_get_post_codegen_info(void);
mxArray *sf_c3_onetwo_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals", "postCodegenInfo" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1, 1, sizeof
    (autoinheritanceFields)/sizeof(autoinheritanceFields[0]),
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("rz5CMHLQFN8556lP76FIlG");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,5,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  {
    mxArray* mxPostCodegenInfo = sf_c3_onetwo_get_post_codegen_info();
    mxSetField(mxAutoinheritanceInfo,0,"postCodegenInfo",mxPostCodegenInfo);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c3_onetwo_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c3_onetwo_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "incompatibleSymbol", };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 3, infoFields);
  mxArray *fallbackReason = mxCreateString("feature_off");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxArray *fallbackType = mxCreateString("early");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c3_onetwo_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

mxArray* sf_c3_onetwo_get_post_codegen_info(void)
{
  const char* fieldNames[] = { "exportedFunctionsUsedByThisChart",
    "exportedFunctionsChecksum" };

  mwSize dims[2] = { 1, 1 };

  mxArray* mxPostCodegenInfo = mxCreateStructArray(2, dims, sizeof(fieldNames)/
    sizeof(fieldNames[0]), fieldNames);

  {
    mxArray* mxExportedFunctionsChecksum = mxCreateString("");
    mwSize exp_dims[2] = { 0, 1 };

    mxArray* mxExportedFunctionsUsedByThisChart = mxCreateCellArray(2, exp_dims);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsUsedByThisChart",
               mxExportedFunctionsUsedByThisChart);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsChecksum",
               mxExportedFunctionsChecksum);
  }

  return mxPostCodegenInfo;
}

static const mxArray *sf_get_sim_state_info_c3_onetwo(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"ss\",},{M[8],M[0],T\"is_active_c3_onetwo\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c3_onetwo_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc3_onetwoInstanceStruct *chartInstance;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    chartInstance = (SFc3_onetwoInstanceStruct *) chartInfo->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _onetwoMachineNumber_,
           3,
           1,
           1,
           0,
           6,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           (void *)S);

        /* Each instance must initialize its own list of scripts */
        init_script_number_translation(_onetwoMachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_onetwoMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _onetwoMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,"u");
          _SFD_SET_DATA_PROPS(1,1,1,0,"a");
          _SFD_SET_DATA_PROPS(2,1,1,0,"v");
          _SFD_SET_DATA_PROPS(3,2,0,1,"ss");
          _SFD_SET_DATA_PROPS(4,1,1,0,"t");
          _SFD_SET_DATA_PROPS(5,1,1,0,"J");
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,23,0,0,0,0,0,38,19);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,3577);
        _SFD_CV_INIT_EML_IF(0,1,0,455,466,1277,3577);
        _SFD_CV_INIT_EML_IF(0,1,1,477,492,-1,541);
        _SFD_CV_INIT_EML_IF(0,1,2,546,562,-1,649);
        _SFD_CV_INIT_EML_IF(0,1,3,654,670,-1,783);
        _SFD_CV_INIT_EML_IF(0,1,4,788,804,-1,859);
        _SFD_CV_INIT_EML_IF(0,1,5,864,880,-1,967);
        _SFD_CV_INIT_EML_IF(0,1,6,972,988,-1,1079);
        _SFD_CV_INIT_EML_IF(0,1,7,1084,1100,-1,1217);
        _SFD_CV_INIT_EML_IF(0,1,8,1222,1229,-1,1266);
        _SFD_CV_INIT_EML_IF(0,1,9,1282,1322,2772,3573);
        _SFD_CV_INIT_EML_IF(0,1,10,2040,2055,-1,2104);
        _SFD_CV_INIT_EML_IF(0,1,11,2109,2125,-1,2213);
        _SFD_CV_INIT_EML_IF(0,1,12,2222,2238,-1,2355);
        _SFD_CV_INIT_EML_IF(0,1,13,2361,2377,-1,2465);
        _SFD_CV_INIT_EML_IF(0,1,14,2470,2486,-1,2576);
        _SFD_CV_INIT_EML_IF(0,1,15,2581,2597,-1,2715);
        _SFD_CV_INIT_EML_IF(0,1,16,2720,2727,-1,2762);
        _SFD_CV_INIT_EML_IF(0,1,17,2777,2813,-1,3565);
        _SFD_CV_INIT_EML_IF(0,1,18,3101,3116,-1,3146);
        _SFD_CV_INIT_EML_IF(0,1,19,3151,3167,-1,3286);
        _SFD_CV_INIT_EML_IF(0,1,20,3312,3328,-1,3414);
        _SFD_CV_INIT_EML_IF(0,1,21,3420,3436,-1,3519);
        _SFD_CV_INIT_EML_IF(0,1,22,3524,3531,-1,3557);

        {
          static int condStart[] = { 480, 487 };

          static int condEnd[] = { 483, 492 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,0,480,492,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 549, 557 };

          static int condEnd[] = { 553, 562 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,1,549,562,2,2,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 657, 665 };

          static int condEnd[] = { 661, 670 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,2,657,670,2,4,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 791, 799 };

          static int condEnd[] = { 795, 804 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,3,791,804,2,6,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 867, 875 };

          static int condEnd[] = { 871, 880 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,4,867,880,2,8,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 975, 983 };

          static int condEnd[] = { 979, 988 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,5,975,988,2,10,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1087, 1095 };

          static int condEnd[] = { 1091, 1100 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,6,1087,1100,2,12,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 1286, 1316 };

          static int condEnd[] = { 1312, 1322 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,7,1286,1322,2,14,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2043, 2050 };

          static int condEnd[] = { 2046, 2055 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,8,2043,2055,2,16,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2112, 2120 };

          static int condEnd[] = { 2116, 2125 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,9,2112,2125,2,18,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2225, 2233 };

          static int condEnd[] = { 2229, 2238 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,10,2225,2238,2,20,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2364, 2372 };

          static int condEnd[] = { 2368, 2377 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,11,2364,2377,2,22,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2473, 2481 };

          static int condEnd[] = { 2477, 2486 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,12,2473,2486,2,24,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2584, 2592 };

          static int condEnd[] = { 2588, 2597 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,13,2584,2597,2,26,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 2781, 2810 };

          static int condEnd[] = { 2806, 2813 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,14,2781,2813,2,28,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3104, 3111 };

          static int condEnd[] = { 3107, 3116 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,15,3104,3116,2,30,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3154, 3162 };

          static int condEnd[] = { 3158, 3167 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,16,3154,3167,2,32,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3315, 3323 };

          static int condEnd[] = { 3319, 3328 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,17,3315,3328,2,34,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 3423, 3431 };

          static int condEnd[] = { 3427, 3436 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,18,3423,3436,2,36,&(condStart[0]),&(condEnd
            [0]),3,&(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML_RELATIONAL(0,1,0,459,466,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,1,480,483,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,2,487,492,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,3,549,553,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,4,557,562,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,5,657,661,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,6,665,670,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,7,791,795,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,8,799,804,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,9,867,871,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,10,875,880,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,11,975,979,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,12,983,988,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,13,1087,1091,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,14,1095,1100,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,15,1225,1229,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,16,1286,1312,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,17,1316,1322,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,18,2043,2046,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,19,2050,2055,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,20,2112,2116,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,21,2120,2125,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,22,2225,2229,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,23,2233,2238,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,24,2364,2368,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,25,2372,2377,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,26,2473,2477,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,27,2481,2486,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,28,2584,2588,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,29,2592,2597,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,30,2723,2727,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,31,2781,2806,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,32,2810,2813,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,33,3104,3107,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,34,3111,3116,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,35,3154,3158,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,36,3162,3167,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,37,3315,3319,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,38,3323,3328,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,39,3423,3427,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,40,3431,3436,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,41,3527,3531,-1,4);
        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)c3_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c3_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_VALUE_PTR(0U, chartInstance->c3_u);
        _SFD_SET_DATA_VALUE_PTR(1U, chartInstance->c3_a);
        _SFD_SET_DATA_VALUE_PTR(2U, chartInstance->c3_v);
        _SFD_SET_DATA_VALUE_PTR(3U, chartInstance->c3_ss);
        _SFD_SET_DATA_VALUE_PTR(4U, chartInstance->c3_t);
        _SFD_SET_DATA_VALUE_PTR(5U, chartInstance->c3_J);
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _onetwoMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "9xYc7wpn14kTg53PcQr44B";
}

static void sf_opaque_initialize_c3_onetwo(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc3_onetwoInstanceStruct*) chartInstanceVar)->S,
    0);
  initialize_params_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
  initialize_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c3_onetwo(void *chartInstanceVar)
{
  enable_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c3_onetwo(void *chartInstanceVar)
{
  disable_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c3_onetwo(void *chartInstanceVar)
{
  sf_gateway_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c3_onetwo(SimStruct* S)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  return get_sim_state_c3_onetwo((SFc3_onetwoInstanceStruct*)
    chartInfo->chartInstance);         /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c3_onetwo(SimStruct* S, const mxArray *st)
{
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
  ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
  set_sim_state_c3_onetwo((SFc3_onetwoInstanceStruct*)chartInfo->chartInstance,
    st);
}

static void sf_opaque_terminate_c3_onetwo(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc3_onetwoInstanceStruct*) chartInstanceVar)->S;
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_onetwo_optimization_info();
    }

    finalize_c3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (crtInfo != NULL) {
      utFree(crtInfo);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc3_onetwo((SFc3_onetwoInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c3_onetwo(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)(ssGetUserData(S));
    ChartInfoStruct * chartInfo = (ChartInfoStruct *)(crtInfo->instanceInfo);
    initialize_params_c3_onetwo((SFc3_onetwoInstanceStruct*)
      (chartInfo->chartInstance));
  }
}

static void mdlSetWorkWidths_c3_onetwo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_onetwo_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,3);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(sf_get_instance_specialization(),
                infoStruct,3,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,3,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_update_buildInfo(sf_get_instance_specialization(),infoStruct,3);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,3,5);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,3,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 5; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,3);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(1675919407U));
  ssSetChecksum1(S,(2475108639U));
  ssSetChecksum2(S,(3171431132U));
  ssSetChecksum3(S,(1646863063U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c3_onetwo(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c3_onetwo(SimStruct *S)
{
  SFc3_onetwoInstanceStruct *chartInstance;
  ChartRunTimeInfo * crtInfo = (ChartRunTimeInfo *)utMalloc(sizeof
    (ChartRunTimeInfo));
  chartInstance = (SFc3_onetwoInstanceStruct *)utMalloc(sizeof
    (SFc3_onetwoInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc3_onetwoInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c3_onetwo;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c3_onetwo;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c3_onetwo;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c3_onetwo;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c3_onetwo;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c3_onetwo;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c3_onetwo;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c3_onetwo;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c3_onetwo;
  chartInstance->chartInfo.mdlStart = mdlStart_c3_onetwo;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c3_onetwo;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  crtInfo->checksum = SF_RUNTIME_INFO_CHECKSUM;
  crtInfo->instanceInfo = (&(chartInstance->chartInfo));
  crtInfo->isJITEnabled = false;
  crtInfo->compiledInfo = NULL;
  ssSetUserData(S,(void *)(crtInfo));  /* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
  chart_debug_initialization(S,1);
}

void c3_onetwo_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c3_onetwo(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c3_onetwo(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c3_onetwo(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c3_onetwo_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
