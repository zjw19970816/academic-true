#ifndef __c1_WADRCguiji_h__
#define __c1_WADRCguiji_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc1_WADRCguijiInstanceStruct
#define typedef_SFc1_WADRCguijiInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c1_sfEvent;
  boolean_T c1_isStable;
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_is_active_c1_WADRCguiji;
  real_T *c1_u;
  real_T *c1_a;
  real_T *c1_v;
  real_T *c1_ss;
  real_T *c1_t;
  real_T *c1_J;
} SFc1_WADRCguijiInstanceStruct;

#endif                                 /*typedef_SFc1_WADRCguijiInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_WADRCguiji_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_WADRCguiji_get_check_sum(mxArray *plhs[]);
extern void c1_WADRCguiji_method_dispatcher(SimStruct *S, int_T method, void
  *data);

#endif
